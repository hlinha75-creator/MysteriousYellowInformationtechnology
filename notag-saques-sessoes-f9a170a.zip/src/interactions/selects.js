const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
  ModalBuilder,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');
const events = require('../modules/events/events.service');
const eventsRepo = require('../modules/events/events.repository');
const deposit = require('../modules/deposit/deposit.service');
const memberProfile = require('../modules/members/profile.service');
const { can } = require('../config/permissions');

async function handleSelect(interaction) {
  const [scope, action, id, messageId] = interaction.customId.split(':');
  if (['auction_channel_select', 'faq_tutorial', 'poll'].includes(scope)) {
    return pausedFeatureReply(interaction);
  }

  if (scope === 'event' && action === 'join') {
    const role = interaction.values[0];
    if (eventsRepo.getCustomEventMeta(Number(id))) {
      const options = events.customEventSlotOptions(Number(id), role, interaction.user.id);
      if (options.length === 0) {
        return interaction.update({ content: `Nao ha vagas livres para ${roleLabel(role)}.`, components: [] });
      }
      return interaction.update({
        content: `Agora escolha exatamente qual vaga de **${roleLabel(role)}** voce quer:`,
        components: customSlotSelectRows(Number(id), role, options)
      });
    }
    try {
      await events.joinEvent(interaction, Number(id), role);
    } catch (error) {
      if (String(error.message || '').includes('Nao ha vaga')) {
        return interaction.reply({ content: error.message, flags: MessageFlags.Ephemeral });
      }
      throw error;
    }
    return interaction.reply({ content: `Voce entrou como ${roleLabel(role)}.`, flags: MessageFlags.Ephemeral });
  }

  if (scope === 'event_custom_slot' && action === 'join') {
    const [role, slotIndex] = interaction.values[0].split('|');
    try {
      await events.joinCustomEventSlot(interaction, Number(id), role, Number(slotIndex));
    } catch (error) {
      if (String(error.message || '').includes('vaga')) {
        return interaction.reply({ content: error.message, flags: MessageFlags.Ephemeral });
      }
      throw error;
    }
    const event = eventsRepo.getEvent(Number(id));
    const isLooter = role === 'dps' && Number(slotIndex) === Number(event?.dps_slots);
    const label = isLooter ? 'Looter' : `${roleLabel(role)} ${slotIndex}`;
    return interaction.update({ content: `Voce entrou na vaga **${label}**.`, components: [] });
  }

  if (scope === 'event_raid_weapon_select' && action === 'weapon') {
    const role = messageId;
    const weaponKey = interaction.values[0];
    const weapon = events.raidWeaponName(role, weaponKey);
    return showModal(interaction, `event:raid_join:${id}:${role}:${weaponKey}`, `Raid Full - ${weapon}`, [
      input('itemPower', 'IP da arma', '', 'Ex: 1500')
    ]);
  }

  if (scope === 'event_raid_weapon_select' && action === 'slot') {
    const [role, weaponKey] = interaction.values[0].split('|');
    const weapon = events.raidWeaponName(role, weaponKey);
    return showModal(interaction, `event:raid_join:${id}:${role}:${weaponKey}`, `Raid Full - ${weapon}`, [
      input('itemPower', 'IP da arma', '', 'Ex: 1500')
    ]);
  }

  if (scope === 'event_world_boss_slot' && action === 'slot') {
    const slotKey = interaction.values[0];
    const slot = events.worldBossSlot(slotKey);
    if (!slot) throw new Error('Vaga de World Boss invalida.');
    return interaction.update({
      content: worldBossConfirmationText(slot.label),
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`event:wb_confirm:${id}:${slotKey}`).setLabel('Confirmar funcao').setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId(`event:wb_abort:${id}:${slotKey}`).setLabel('Cancelar').setStyle(ButtonStyle.Secondary)
        )
      ]
    });
  }

  if (scope === 'event_world_boss_slot' && action === 'remove') {
    const slot = await events.removeWorldBossSlot(interaction, Number(id), interaction.values[0]);
    return interaction.update({ content: `Vaga liberada: **${slot.label}**.`, components: [] });
  }

  if (scope === 'event_review_select') {
    const eventId = Number(id);
    const event = eventsRepo.getEvent(eventId);
    if (!event) throw new Error('Evento nao encontrado.');
    if (event.creator_id !== interaction.user.id && !can(interaction.member, 'assumeEvent')) {
      return interaction.reply({ content: 'Somente o criador ou alguem autorizado pode editar a revisao.', flags: MessageFlags.Ephemeral });
    }

    const discordId = interaction.values[0];
    const participant = eventsRepo.getParticipant({ eventId, discordId });
    if (!participant) throw new Error('Participante nao encontrado.');

    if (action === 'edit') {
      const seconds = participant.manual_seconds ?? participant.calculated_seconds ?? 0;
      return showModal(interaction, `event_review:edit_modal:${eventId}:${messageId}`, 'Editar membro do split', [
        input('userId', 'Membro', discordId),
        input('role', 'Funcao', roleLabel(participant.role), 'Ex: tank, healer, sup, dps'),
        input('minutes', 'Tempo contado em minutos', String(Math.round(seconds / 60)), 'Ex: 75 para 1h15min'),
        input('reason', 'Motivo do ajuste', '', 'Ex: caiu da call e voltou', false)
      ]);
    }

    if (action === 'remove') {
      return showModal(interaction, `event_review:remove_modal:${eventId}:${messageId}`, 'Remover membro do split', [
        input('userId', 'Membro', discordId),
        input('reason', 'Motivo da remocao', '', 'Ex: estava como espectador', false)
      ]);
    }
  }

  if (scope === 'event_review_user_select') {
    const eventId = Number(id);
    const event = eventsRepo.getEvent(eventId);
    if (!event) throw new Error('Evento nao encontrado.');
    if (event.creator_id !== interaction.user.id && !can(interaction.member, 'assumeEvent')) {
      return interaction.reply({ content: 'Somente o criador ou alguem autorizado pode editar a revisao.', flags: MessageFlags.Ephemeral });
    }

    const discordId = interaction.values[0];

    if (action === 'add') {
      return showModal(interaction, `event_review:add_modal:${eventId}:${messageId}`, 'Adicionar membro ao split', [
        input('userId', 'Membro', discordId),
        input('role', 'Funcao', '', 'Ex: tank, healer, sup, dps'),
        input('minutes', 'Tempo contado em minutos', '', 'Ex: 75 para 1h15min'),
        input('reason', 'Motivo da inclusao', '', 'Ex: entrou depois e nao clicou participar', false)
      ]);
    }

    const participant = eventsRepo.getParticipant({ eventId, discordId });
    if (!participant) {
      return interaction.reply({
        content: 'Esse membro ainda nao esta no split. Use Adicionar membro para colocar ele na revisao.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (action === 'edit') {
      const seconds = participant.manual_seconds ?? participant.calculated_seconds ?? 0;
      return showModal(interaction, `event_review:edit_modal:${eventId}:${messageId}`, 'Editar membro do split', [
        input('userId', 'Membro', discordId),
        input('role', 'Funcao', roleLabel(participant.role), 'Ex: tank, healer, sup, dps'),
        input('minutes', 'Tempo contado em minutos', String(Math.round(seconds / 60)), 'Ex: 75 para 1h15min'),
        input('reason', 'Motivo do ajuste', '', 'Ex: caiu da call e voltou', false)
      ]);
    }

    if (action === 'remove') {
      return showModal(interaction, `event_review:remove_modal:${eventId}:${messageId}`, 'Remover membro do split', [
        input('userId', 'Membro', discordId),
        input('reason', 'Motivo da remocao', '', 'Ex: estava como espectador', false)
      ]);
    }
  }

  if (scope === 'admin_remove_balance_select') {
    if (!can(interaction.member, 'withdrawBalance')) {
      return interaction.reply({ content: 'Sem permissao para retirar saldo.', flags: MessageFlags.Ephemeral });
    }

    const discordId = interaction.values[0];
    return showModal(interaction, 'admin:remove_balance_modal', 'Retirar Saldo', [
      input('userId', 'Membro', discordId),
      input('amount', 'Valor', '', 'Ex: 1000000 ou 1m'),
      input('reason', 'Motivo', '', 'Ex: saque pago, ajuste manual'),
      input('confirmation', 'CONFIRMAR se ficar negativo', '', 'Digite CONFIRMAR se o saldo ficar negativo', false)
    ]);
  }

  if (scope === 'admin_profile_select') {
    if (!can(interaction.member, 'approveRegistration') && !can(interaction.member, 'approvePayment')) {
      return interaction.reply({ content: 'Sem permissao para ver perfil de membro.', flags: MessageFlags.Ephemeral });
    }
    const discordId = interaction.values[0];
    return interaction.reply({ ...(await memberProfile.memberProfilePayload(discordId, interaction.guild)), flags: MessageFlags.Ephemeral });
  }

  if (scope === 'deposit_select') {
    if (!can(interaction.member, 'approvePayment')) {
      return interaction.reply({ content: 'Sem permissao para editar deposito.', flags: MessageFlags.Ephemeral });
    }

    const draft = deposit.addParticipants({ draftId: id, userIds: interaction.values });
    await interaction.update({
      content: 'Participantes atualizados. Voce pode selecionar mais membros ou confirmar o deposito.',
      embeds: [deposit.draftEmbed(draft)],
      components: deposit.draftComponents(draft.id)
    });
  }
}

module.exports = {
  handleSelect
};

function pausedFeatureReply(interaction) {
  return interaction.reply({
    content: 'Esse recurso foi pausado para simplificar o bot. Use os paineis principais de evento, saldo, registro ou ADM.',
    flags: MessageFlags.Ephemeral
  });
}

function showModal(interaction, customId, title, inputs) {
  const modal = new ModalBuilder()
    .setCustomId(customId)
    .setTitle(title)
    .addComponents(inputs.map((component) => new ActionRowBuilder().addComponents(component)));
  return interaction.showModal(modal);
}

function input(id, label, value = '', placeholder = null, required = true) {
  const component = new TextInputBuilder()
    .setCustomId(id)
    .setLabel(label)
    .setStyle(TextInputStyle.Short)
    .setRequired(required);
  if (value) component.setValue(value);
  if (placeholder) component.setPlaceholder(placeholder);
  return component;
}

function roleLabel(role) {
  const labels = {
    tank: 'Tank',
    healer: 'Healer',
    support: 'Suporte',
    dps: 'DPS'
  };
  return labels[role] || role;
}

function worldBossConfirmationText(slotLabel) {
  return [
    '## \u26A0\uFE0F CONFIRMACAO DA FUNCAO',
    '',
    `Voce escolheu: **${slotLabel}**`,
    '',
    '\u2022 Avise com antecedencia caso precise desistir.',
    '\u2022 Use **Gerenciar vagas** para liberar a funcao e retirar seu ping.',
    '\u2022 A organizacao esta pagando o mapa.',
    '\u2022 O loot de dentro do World Boss sera usado para pagar o rent.',
    '\u2022 Scouts Ativos recebem **1m de loot** como auxilio.',
    '\u2022 DPS devem usar arma **T9 ou 6.3**.',
    '\u2022 Main Roles devem seguir exatamente a imagem da build.',
    '\u2022 Nao teremos FE/Basilisco.',
    '\u2022 O foco e aprender, adaptar o content e criar constancia.',
    '\u2022 Scout Mobile com funcao DPS pode acumular as duas vagas.'
  ].join('\n');
}

function customSlotSelectRows(eventId, role, options) {
  const rows = [];
  for (let start = 0; start < options.length; start += 25) {
    const page = Math.floor(start / 25) + 1;
    const pageSuffix = options.length > 25 ? ` (${page}/${Math.ceil(options.length / 25)})` : '';
    rows.push(new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`event_custom_slot:join:${eventId}:${page}`)
        .setPlaceholder(`Escolha uma vaga de ${roleLabel(role)}${pageSuffix}`)
        .addOptions(options.slice(start, start + 25))
    ));
  }
  return rows;
}
